Edelwise_Data<- read.csv("C:/Users/leelavathi.a/Desktop/118_22112016174157.csv")

# install.packages("Rserve")
# 
# library(Rserve)
# 
# Rserve()


str(Edelwise_Data)
library(dplyr)
Edelwise_Data$Month<-as.Date(paste0(as.character(Edelwise_Data$Month),"-01",""),format="%b-%y-%d")

Edelwise_Data$Distributor.Category=as.character(Edelwise_Data$Distributor.Category)


#####      Excluding Direct and others categories #########
Edelwise_Data_subset_data<-Edelwise_Data[!Edelwise_Data$Distributor.Category %in% c("Direct", "Others"),] 


Edelwise_Data_subset_data$Distributor.Category=ifelse(Edelwise_Data_subset_data$Distributor.Category %in% c("Bank-Pvt/Foreign" ,"Bank-Others","Bank-PSU"),"Bank",ifelse(Edelwise_Data_subset_data  $Distributor.Category %in% c("ND-RD"  , "ND" ,"National /Regional Distributor"),"ND-RD",Edelwise_Data_subset_data$Distributor.Category)) 


Edelwise_Data_subset_data<-Edelwise_Data_subset_data %>% select(Distributor.Name,Distributor.Code,Investor.Category,Asset.Class,Month,AUM,Distributor.Category)

###### creating dataframe to store results #####
Test_forecasted_AUM=data.frame(Distributor_Name=character()
                               ,Distributor_Code=character(),Investor_Category=character()
                               ,Asset_Class=character(),Month = as.Date(character
                                                                        ()),ForecastingTechnique=character(), Actual_AUM=numeric()
                               ,Forecasted_AUM=numeric(),Distributor.Category=character())

Test_forecasted_MAPE=data.frame(Distributor_Name=character
                                (),Distributor_Code=character(),Investor_Category=character
                                (),Asset_Class=character(),ForecastingTechnique=character(),MAPE=numeric
                                (),MAPE_manual=numeric(),Distributor.Category=character())

Distributor_Category_unique<-unique(Edelwise_Data_subset_data$Distributor.Category)

for(l in 1:length(Distributor_Category_unique))
{
  Distributor_category<-subset(Edelwise_Data_subset_data,Distributor.Category== Distributor_Category_unique [l])
  
  
  Distributor_Code_unique<-as.character(unique(Distributor_category$Distributor.Code))
  
  
  
  
  for(i in 1:length(Distributor_Code_unique))
  {
    Distributor_code<-subset(Distributor_category,Distributor.Code== Distributor_Code_unique[i]) 
    
    Investor_Category_unique<-as.character(unique(Distributor_code $Investor.Category))
    
    
    
    
    for(j in 1:length(Investor_Category_unique))
    {
      Distributor_code_investor<-subset(Distributor_code,Investor.Category== Investor_Category_unique[j])
      
      Asset_Class_unique<-as.character(unique(Distributor_code_investor$Asset.Class))
      
      
      
      for(k in 1:length(Asset_Class_unique)){
        Distributor_code_investor_Asset_Class<- subset(Distributor_code_investor,Asset.Class== Asset_Class_unique[k])
        
        
        
        if(nrow(Distributor_code_investor_Asset_Class)>12 & nrow (Distributor_code_investor_Asset_Class[Distributor_code_investor_Asset_Class$AUM==0,])<=4 )
          
        {
          
          Distributor_code_investor_Asset_Class=Distributor_code_investor_Asset_Class [order(Distributor_code_investor_Asset_Class$Month),]
          
          IFA_Year=as.numeric(format(min(Distributor_code_investor_Asset_Class$Month), "%Y"))
          
          IFA_Month=as.numeric(format(min(Distributor_code_investor_Asset_Class$Month), "%m"))
          
          
          
          IFA_Train=Distributor_code_investor_Asset_Class[1:(nrow (Distributor_code_investor_Asset_Class)-4),]
          
          IFA_Test=Distributor_code_investor_Asset_Class[-(1:(nrow (Distributor_code_investor_Asset_Class)-4)),]
          
          if(nrow(IFA_Test[IFA_Test$AUM==0,])<1 & nrow(IFA_Train)>26 & length(unique(IFA_Train$AUM))>15)
          {
            print(k)
            IFA_TS=ts(IFA_Train$AUM, frequency=12,start=c(IFA_Year,IFA_Month))
            
            
            ######### Holt-Damped ##########
            
            IFA_Fit_holt = (holt(IFA_TS,alpha=0.8, beta=0.2, damped=TRUE, initial="simple", h=16)) 
            
            IFA_Fit_holt1<-data.frame(IFA_Fit_holt)
            IFA_Fit_holt1$Point.Forecast
            IFA_Fit_holt2<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],Month =c(IFA_Test[,5],IFA_Test[4,5]+seq(31,373,31)) ,ForecastingTechnique="Holt-Damped",Actual_AUM=c(IFA_Test[,6],rep (NA,12)),Forecasted_AUM=IFA_Fit_holt1$Point.Forecast,Distributor.Category=Distributor_Category_unique[l])           
            
            x<-cbind(IFA_Train[,c(1:5)],ForecastingTechnique="Holt-Damped",Actual_AUM=IFA_Train[,6],Forecasted_AUM=rep(NA,nrow(IFA_Train)),Distributor.Category=Distributor_Category_unique[l])                                     
            
            ALL1<-data.frame(aum=IFA_Test[,6])                                                                                                                                             
            
            colnames(x)<-colnames(IFA_Fit_holt2)
            Test_forecasted_AUM<-rbind(Test_forecasted_AUM,x,IFA_Fit_holt2)                                                                                                                 
            
            MAPE_M<- (abs(mean((ALL1$aum-IFA_Fit_holt2$Forecasted_AUM[1:4])/ALL1$aum))*100) 
            m<-data.frame(accuracy(IFA_Fit_holt2$Forecasted_AUM[1:4],IFA_Test[,6]))                               
            IFA_Fit_holt_MAPE<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],ForecastingTechnique="Holt-Damped",MAPE=m$MAPE,MAPE_manual=MAPE_M,Distributor.Category=Distributor_Category_unique[l]) 
            Test_forecasted_MAPE<-rbind(Test_forecasted_MAPE,IFA_Fit_holt_MAPE)
            
            
            
            ###########  Auto-Arima ########                               
            IFA_Fit_AutoArima=auto.arima(IFA_TS)
            IFA_Forecast <- data.frame(forecast(IFA_Fit_AutoArima,h=16))                              
            IFA1<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],Month =c(IFA_Test[,5],IFA_Test[4,5]+seq(31,373,31)) ,ForecastingTechnique="Auto-Arima",Actual_AUM=c(IFA_Test[,6],rep  (NA,12)),Forecasted_AUM=IFA_Forecast $Point.Forecast,Distributor.Category=Distributor_Category_unique[l])       
            x<-cbind(IFA_Train[,c(1:5)],ForecastingTechnique="Auto-Arima",Actual_AUM=IFA_Train[,6],Forecasted_AUM=rep(NA,nrow(IFA_Train)),Distributor.Category=Distributor_Category_unique[l])                 
            ALL_validation<-data.frame(aum=IFA_Test[,6])
            colnames(x)<-colnames(IFA1)                                                            
            Test_forecasted_AUM<-rbind(Test_forecasted_AUM,x,IFA1)                                                                                                                                        
            
            MAPE_M<- (abs(mean((ALL_validation$aum-IFA1$Forecasted_AUM  [1:4])/ALL_validation$aum))*100)    
            M<-data.frame(accuracy(IFA1$Forecasted_AUM[1:4],IFA_Test[,6]))                       
            IFA_Fit_AutoArima_MAPE<-data.frame(Distributor_Name=IFA_Train [1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train  [1,3],Asset_Class=IFA_Train[1,4],ForecastingTechnique="Auto-Arima",MAPE=M $MAPE,MAPE_manual=MAPE_M,Distributor.Category=Distributor_Category_unique[l])    
            Test_forecasted_MAPE<-rbind(Test_forecasted_MAPE,IFA_Fit_AutoArima_MAPE)
            
            
            ######## nnet ##############         
            
            fit1 = nnetar(IFA_TS)           
            fcast <- data.frame(forecast(fit1,h=16))          
            d1<-data.frame(t(fcast))          
            if(ncol(d1)>=2){
              fcast=rbind(data.frame(x=d1[!(d1[,1] %in% c ("NA","")),1]),data.frame(x=d1[!(d1[,2]%in% c("NA","")),2]))
              
              fcast[,1]=as.numeric(as.character(fcast[,1]))
            }
            if(ncol(d1)<2){
              fcast<-d1
              fcast[,1]=as.numeric(as.character(fcast[,1]))
            }                           
            
            colnames(fcast)<-"Forecasted_AUM"                   
            
            fcast1<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],Month =c(IFA_Test[,5],IFA_Test[4,5]+seq (31,373,31)) ,ForecastingTechnique="NeuralNetworkForecasting",Actual_AUM=c(IFA_Test[,6],rep(NA,12)),Forecasted_AUM=IFA_Forecast$Point.Forecast,Distributor.Category=Distributor_Category_unique[l])  
            
            x<-cbind(IFA_Train[,c(1:5)],ForecastingTechnique="NeuralNetworkForecasting",Actual_AUM=IFA_Train [,6],Forecasted_AUM=rep(NA,nrow (IFA_Train)),Distributor.Category=Distributor_Category_unique[l]) 
            
            colnames(x)<-colnames(fcast1)
            Test_forecasted_AUM<-rbind(Test_forecasted_AUM,x,fcast1)         
            ALL12<-data.frame(aum=IFA_Test[,6])                                                    
            mn<-data.frame(accuracy(fcast1$Forecasted_AUM[1:4],IFA_Test[,6]))                                                              
            
            MAPE_MN<-(abs(mean((ALL12$aum - fcast1$Forecasted_AUM [1:4])/ALL12$aum ))*100) 
            
            IFA_Fit_nnet_MAPE<-data.frame(Distributor_Name=IFA_Train [1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],ForecastingTechnique="NeuralNetworkForecasting",MAPE=mn $MAPE,MAPE_manual=MAPE_MN,Distributor.Category=Distributor_Category_unique[l])  
            
            
            Test_forecasted_MAPE<-rbind(Test_forecasted_MAPE,IFA_Fit_nnet_MAPE)
            
            
          }
          
        }
      } 
      
    }
    
  }
}                               


write.csv(Test_forecasted_AUM,"C:/Users/leelavathi.a/Desktop/YEAR_forecasted_AUM_ALL.csv")
write.csv(Test_forecasted_MAPE,"C:/Users/leelavathi.a/Desktop/YEAR_forecasted_MAPE.csv")





write.csv(Edelwise_Data_subset_data,"C:/Users/leelavathi.a/Desktop/Edelwise_Data_subset_data.csv")

























