
Lat_forecasted_AUM_ALL <- read.csv("C:/Users/leelavathi.a/Desktop/Lat_forecasted_AUM_ALL.csv")
Lat_forecasted_AUM_ALL$new_AUM=0
Lat_forecasted_AUM_ALL$indiacator=""
for (i in 1:nrow(Lat_forecasted_AUM_ALL))
{
  
  if(is.na(Lat_forecasted_AUM_ALL$Actual_AUM[i]))
  {
    Lat_forecasted_AUM_ALL$new_AUM[i]=Lat_forecasted_AUM_ALL$Forecasted_AUM[i]
    Lat_forecasted_AUM_ALL$indiacator[i]="forecast"
  }
  else
  {
    Lat_forecasted_AUM_ALL$new_AUM[i]=Lat_forecasted_AUM_ALL$Actual_AUM[i]
    Lat_forecasted_AUM_ALL$indiacator[i]="Actual"
  }
}

write.csv(Lat_forecasted_AUM_ALL,"C:/Users/leelavathi.a/Desktop/modified_data.csv")



###############year###############
YEAR_forecasted_AUM_ALL <- read.csv("C:/Users/leelavathi.a/Desktop/YEAR_forecasted_AUM_ALL.csv")
YEAR_forecasted_AUM_ALL$new_AUM=0
YEAR_forecasted_AUM_ALL$indiacator=""
for(i in 1:nrow(YEAR_forecasted_AUM_ALL))
{
  if(is.na(YEAR_forecasted_AUM_ALL$Actual_AUM[i]))
  {
    YEAR_forecasted_AUM_ALL$new_AUM[i]=YEAR_forecasted_AUM_ALL$Forecasted_AUM[i]
    YEAR_forecasted_AUM_ALL$indiacator[i]="forecast"
  }
    else
    {
      YEAR_forecasted_AUM_ALL$new_AUM[i]=YEAR_forecasted_AUM_ALL$Actual_AUM[i]
      YEAR_forecasted_AUM_ALL$indiacator[i]="Actual"
      
    }
  
}

write.csv(YEAR_forecasted_AUM_ALL,"C:/Users/leelavathi.a/Desktop/YEAR_modified_data.csv")

############# Data modifying for dashboard #########
YEAR_forecasted_AUM_ALL$indiacator1=""
Final_dataframe<- YEAR_forecasted_AUM_ALL[0,]
Distributor_Category_unique<-unique(YEAR_forecasted_AUM_ALL$Distributor.Category)

for(l in 1:length(Distributor_Category_unique))
{
  Distributor_category<-subset(YEAR_forecasted_AUM_ALL,Distributor.Category== Distributor_Category_unique [l])
  
  
  Distributor_Code_unique<-as.character(unique(Distributor_category$Distributor_Code))
  
  
  
  
  for(i in 1:length(Distributor_Code_unique))
  {
    Distributor_code<-subset(Distributor_category,Distributor_Code== Distributor_Code_unique[i]) 
    
    Investor_Category_unique<-as.character(unique(Distributor_code $Investor_Category))
    
    
    
    
    for(j in 1:length(Investor_Category_unique))
    {
      Distributor_code_investor<-subset(Distributor_code,Investor_Category== Investor_Category_unique[j])
      
      Asset_Class_unique<-as.character(unique(Distributor_code_investor$Asset_Class))
      
      
      
      for(k in 1:length(Asset_Class_unique)){
        Distributor_code_investor_Asset_Class<- subset(Distributor_code_investor,Asset_Class== Asset_Class_unique[k])
        
        forecast_technique_unique=as.character(unique(Distributor_code_investor_Asset_Class$ForecastingTechnique))
        
        for(m in 1:length(forecast_technique_unique)){
          
          Distributor_code_forecast_technique<- subset(Distributor_code_investor_Asset_Class,ForecastingTechnique== forecast_technique_unique[m]) 
          
          temp1=Distributor_code_forecast_technique
          temp1 <- temp1[c(1:(nrow(temp1)-12)),]
          temp1$indiacator1="Actual"
          temp2=Distributor_code_forecast_technique
          temp2= temp2[c(1:(nrow(temp2)-11)),]
          temp2$indiacator1="Next_Month"
          
          temp4=Distributor_code_forecast_technique
          temp4=temp4[c(1:(nrow(temp4)-9)),]
          temp4$indiacator1="Quarter"
          temp3=Distributor_code_forecast_technique
          temp3=temp3[c(1:nrow(temp3)),]
          temp3$indiacator1="Next_Year"
          temp=rbind(temp1,temp2,temp4,temp3)
          Final_dataframe=rbind(temp,Final_dataframe)
          
        }
        
        
        
        
        
        
        
        
      } 
      
    }
    
  }
}     


write.csv(Final_dataframe,"C:/Users/leelavathi.a/Desktop/Final_dataframe_13.csv")



