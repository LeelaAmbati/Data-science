
# GR<-fnal %>% group_by(Distributor_Code,Investor_Category,Asset_Class,ForecastingTechnique) %>% mutate(new=sum(Forecasted_AUM[4:8])/sum(tail(Actual_AUM, 16))*100)





Lat_forecasted_AUM_ALL <- read.csv("C:/Users/leelavathi.a/Desktop/Lat_forecasted_AUM_ALL.csv")
Lat_forecasted_AUM_ALL<-Lat_forecasted_AUM_ALL[,-1]

library(dplyr)

samp<-Lat_forecasted_AUM_ALL %>% group_by(Distributor.Category,Distributor_Name,Distributor_Code,Investor_Category,Asset_Class,ForecastingTechnique) %>% mutate(ChurnRate=round(sum(tail(Forecasted_AUM,3))/sum(tail(Actual_AUM, 15),na.rm=TRUE)*100,2))


final<-unique(samp[,c(1:4,6,9,10)])


write.csv(final,"C:/Users/leelavathi.a/Desktop/Dist_Churn.csv")


write.csv(samp,"C:/Users/leelavathi.a/Desktop/samp.csv")



 
  