Edelwise_Data<- read.csv("C:/Users/leelavathi.a/Desktop/118_22112016174157.csv")

str(Edelwise_Data)
library(dplyr)
Edelwise_Data$Month<-as.Date(paste0(as.character(Edelwise_Data$Month),"-01",""),format="%b-%y-%d")

Edelwise_Data$Distributor.Category=as.character(Edelwise_Data$Distributor.Category)
#####      Excluding Direct and others categories #########
Edelwise_Data_subset_data<-Edelwise_Data[!Edelwise_Data$Distributor.Category %in% c("Direct", "Others"),] 

Edelwise_Data_subset_data$Distributor.Category=ifelse(Edelwise_Data_subset_data$Distributor.Category %in% c("Bank-Pvt/Foreign" ,"Bank-Others","Bank-PSU"),"Bank",ifelse(Edelwise_Data_subset_data$Distributor.Category %in% c("ND-RD"  , "ND" ,"National /Regional Distributor"),"ND-RD",Edelwise_Data_subset_data$Distributor.Category))

Edelwise_Data_subset_data<-Edelwise_Data_subset_data %>% select(Distributor.Name,Distributor.Code,Investor.Category,Asset.Class,Month,AUM,Distributor.Category)

###### creating dataframe to store results #####
Test_forecasted_AUM_IFA=data.frame(Distributor_Category=character(),Distributor_Name=character(),Distributor_Code=character(),Investor_Category=character(),Asset_Class=character(),Month = as.Date(character()),ForecastingTechnique=character(), AUM= numeric(),Forecasted_AUM=numeric())

Test_forecasted_IFA_MAPE=data.frame(Distributor_Category=character(),Distributor_Name=character(),Distributor_Code=character(),Investor_Category=character(),Asset_Class=character(),MAPE=numeric())

Distributor_Category_unique<-unique(Edelwise_Data_subset_data$Distributor.Category)
for(l in 1:length(Distributor_Category_unique))
{
  Distributor_category<-subset(Edelwise_Data_subset_data,Distributor.Category== Distributor_Category_unique[l])
  Distributor_Code_unique<-as.character(unique(Distributor_category$Distributor.Code))
  
  
  
  for(i in 1:length(Distributor_Code_unique))
  {
    Distributor_code<-subset(Distributor_category,Distributor.Code== Distributor_Code_unique[i])
    Investor_Category_unique<-as.character(unique(Distributor_code$Investor.Category))
    
    
    
    for(j in 1:length(Investor_Category_unique))
    {
      Distributor_code_investor<-subset(Distributor_code,Investor.Category== Investor_Category_unique[j])
      Asset_Class_unique<-as.character(unique(Distributor_code_investor$Asset.Class))
      
      
      for(k in 1:length(Asset_Class_unique)){
        Distributor_code_investor_Asset_Class<- subset(Distributor_code_investor,Asset.Class== Asset_Class_unique[k])
        

      if(nrow(Distributor_code_investor_Asset_Class)>12 & nrow(Distributor_code_investor_Asset_Class[Distributor_code_investor_Asset_Class$AUM==0,])<=4 ){
        Distributor_code_investor_Asset_Class=Distributor_code_investor_Asset_Class[order(Distributor_code_investor_Asset_Class$Month),]
        IFA_Year=as.numeric(format(min(Distributor_code_investor_Asset_Class$Month), "%Y"))
        IFA_Month=as.numeric(format(min(Distributor_code_investor_Asset_Class$Month), "%m"))
        
        #IFA_Train=Distributor_code_investor_Asset_Class[(1:(nrow(Distributor_code_investor_Asset_Class)-4)),]
        IFA_Train=Distributor_code_investor_Asset_Class[1:(nrow(Distributor_code_investor_Asset_Class)-4),]
        IFA_Test=Distributor_code_investor_Asset_Class[-(1:(nrow(Distributor_code_investor_Asset_Class)-4)),]
        if(nrow(IFA_Test[IFA_Test$AUM==0,])<1 & nrow(IFA_Train)>26 & length(unique(IFA_Train$AUM))>15){
          IFA_TS=ts(IFA_Train$AUM, frequency=12,start=c(IFA_Year,IFA_Month))
          #             plot(IFA_TS)
          #             O<-decompose(IFA_TS)
          #             plot(O)
######### Holt-Damped ##########
          IFA_Fit_holt = (holt(IFA_TS,alpha=0.8, beta=0.2, damped=TRUE, initial="simple", h=8))
          IFA_Fit_holt1<-data.frame(IFA_Fit_holt)
          IFA_Fit_holt1$Point.Forecast
          IFA_Fit_holt2<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],Month =IFA_Test[,5] ,ForecastingTechnique="Holt-Damped", AUM= IFA_Test[,6],Forecasted_AUM=IFA_Fit_holt1$Point.Forecast)
          Test_forecasted_AUM_IFA<-rbind(Test_forecasted_AUM_IFA,IFA_Fit_holt2)
          MAPE_M<- (abs(mean((IFA_Fit_holt2$AUM-IFA_Fit_holt2$Forecasted_AUM)/IFA_Fit_holt2$AUM))*100)
          m<-data.frame(accuracy(IFA_Fit_holt))
          IFA_Fit_holt_MAPE<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],ForecastingTechnique="Holt-Damped",MAPE=m$MAPE,MAPE_manual=MAPE_M)
          Test_forecasted_IFA_MAPE<-rbind(Test_forecasted_IFA_MAPE,IFA_Fit_holt_MAPE)
###########  Auto-Arima ########
          #             lambda = BoxCox.lambda(IFA_TS)
          #             IFA_TS = BoxCox(IFA_TS, lambda=lambda)
          #             tsdisplay(IFA_TS)
          #             K=ndiffs(IFA_TS)
          #             IFA_TS1 = diff(IFA_TS, differences = K)
          #             plot.ts(IFA_TS1)
          #             IFA_Fit_AutoArima=auto.arima(IFA_TS, trace= TRUE, ic ="aicc", approximation = FALSE, stepwise = FALSE)
          #             AIC(arima(IFA_TS, order = c(0, 1, 0)),
          #                 arima(IFA_TS, order = c(1, 1, 2)))
          IFA_Fit_AutoArima=auto.arima(IFA_TS)
          IFA_Forecast <- data.frame(forecast(IFA_Fit_AutoArima,h=8))
          IFA1<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],Month =IFA_Test[,5] ,ForecastingTechnique="Auto-Arima", AUM= IFA_Test[,6],Forecasted_AUM=IFA_Forecast[,1])
          Test_forecasted_AUM_IFA<-rbind(Test_forecasted_AUM_IFA,IFA1)
          MAPE_M<- (abs(mean((IFA1$AUM-IFA1$Forecasted_AUM)/IFA1$AUM))*100)
          M<-data.frame(accuracy(IFA_Fit_AutoArima))
          IFA_Fit_AutoArima_MAPE<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],ForecastingTechnique="Auto-Arima",MAPE=M$MAPE,MAPE_manual=MAPE_M)
          Test_forecasted_IFA_MAPE<-rbind(Test_forecasted_IFA_MAPE,IFA_Fit_AutoArima_MAPE)
          
######## nnet ##############
          
          fit1 = nnetar(IFA_TS)
          #Box.test(residuals(fit1), lag=12, type="Ljung")
          fcast <- data.frame(forecast(fit1,h=8))
          d1<-data.frame(t(fcast))
          if(ncol(d1)>=2){
            fcast=rbind(data.frame(x=d1[!(d1[,1] %in% c("NA","")),1]),data.frame(x=d1[!(d1[,2]%in% c("NA","")),2]))
            fcast[,1]=as.numeric(as.character(fcast[,1]))
          }
          if(ncol(d1)<2){
            fcast<-d1
            fcast[,1]=as.numeric(as.character(fcast[,1]))
          }
          #             View(fcast)
          #             class(fcast)
          #fcast<-data.frame(fcast)
          
          
          colnames(fcast)<-"Forecasted_AUM"
          fcast1<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],Month =IFA_Test[,5] ,ForecastingTechnique="NeuralNetworkForecasting", AUM= IFA_Test[,6],Forecasted_AUM =fcast)
          # fcast1$Forecasted_AUM<-as.numeric(fcast1$Forecasted_AUM)
          Test_forecasted_AUM_IFA<-rbind(Test_forecasted_AUM_IFA,fcast1)
          mn<-data.frame(accuracy(fit1))
          MAPE_MN<-(abs(mean((fcast1$AUM - fcast1$Forecasted_AUM)/fcast1$AUM))*100)
          IFA_Fit_nnet_MAPE<-data.frame(Distributor_Name=IFA_Train[1,1],Distributor_Code=IFA_Train[1,2],Investor_Category=IFA_Train[1,3],Asset_Class=IFA_Train[1,4],ForecastingTechnique="NeuralNetworkForecasting",MAPE=mn$MAPE,MAPE_manual=MAPE_MN)
          Test_forecasted_IFA_MAPE<-rbind(Test_forecasted_IFA_MAPE,IFA_Fit_nnet_MAPE)
          
        }
        
      }
    } 
    
  }
  
  }
}









write.csv(Test_forecasted_AUM_IFA,"C:/Users/leelavathi.a/Desktop/TesTest_forecasted_AUM_IFA_Manual4.csv")
write.csv(Test_forecasted_IFA_MAPE,"C:/Users/leelavathi.a/Desktop/TesTest_forTest_forecasted_IFA_MAPE_Manual4.csv")
