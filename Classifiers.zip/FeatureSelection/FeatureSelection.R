##################################################### Feature Selection - Iris Data #############################################

#Load Iris Data
data("iris")

#Dividing data into Training and Testing
indexes=sample(1:nrow(iris),size=round(0.7*nrow(iris)))
train=iris[indexes,]
test=iris[-indexes,]

#Subsetting Data For Modeling
X_train=train[,-ncol(iris)] #Training Data - Independent Variables
Y_train=train[,ncol(iris)] #Training Data - Dependent Variable
X_test=test[,-ncol(iris)] #Testing Data - Independent Variables
Y_test=test[,ncol(iris)] #Testing Data - Dependent Variable

#Loading Required Libraries
library(Boruta)
library(caret)
library(FSelector)

#Feature_Selection Function Definition
Feature_Selection<-function(X_train,Y_train,TargetVarb_Name,featureSelect_Method="Boruta",max_Runs=100,k_fold=10,
                            n_times=10,value="InformationGain",k_attrb=ncol(X_train)-1){
  
        ############### Feature Selection - Different Methods
  
        ########### Feature Selection - Boruta ###########
        if(featureSelect_Method=="Boruta"){
              cat('\n')
              cat('##################### Feature Selection Using Boruta ##################\n')
              cat('\n')
              
              #### Boruta Function for Feature Selection/ Variable Importance
              featureSelect_Boruta=Boruta(X_train,Y_train,doTrace = 2,maxRuns = max_Runs)
              
              #### Printing Boruta Summary to R Console
              cat('\n')
              cat('########## Feature Selection using Boruta - Results ##########\n')
              cat('\n')
              cat('############# Summary ############\n')
              print(featureSelect_Boruta)
        
              cat('\n')
              cat('############ Final Decision ###########\n')
              print(featureSelect_Boruta$finalDecision)
              
              cat('\n')
              cat('############ Importance History #########\n')
              print(featureSelect_Boruta$ImpHistory)
              
              cat('\n')
              cat('########### Final Result ############\n')
              print(attStats(featureSelect_Boruta))
              
              cat('\n')
              cat('########### Selected Attributes #########\n')
              ###### Final Selected Attributes ######
              cat(getSelectedAttributes(featureSelect_Boruta))
              
              #Shows Important Bands
              par(mfrow=c(1,1))
              plot(featureSelect_Boruta,sort=TRUE,main='Feature Selection - Boruta')
        }
  
        ############## Recursive Feature Elimination ###############
        if(featureSelect_Method=="RecursiveFeatureElimination"){
          
          # Define the control using a Random Forest Selection Function
          control <- rfeControl(functions=rfFuncs, method="cv", number=k_fold,repeats =n_times )
          
          # Run the RFE Algorithm
          cat('\n')
          cat('############### Feature Selection - Recursive Feature Elimination ##############\n')
          featureSelect_RFE <- rfe(X_train, Y_train, sizes=c(1:ncol(X_train)), rfeControl=control)
          
          # Summarize the Results
          cat('\n')
          cat('################ Recursive Feature Elimination - Results ###########\n')
          print(featureSelect_RFE)
          
          cat('\n')
          cat('################ Recursive Feature Elimination - Variable Importance on Different Cross Validation Folds ###########\n')
          print(featureSelect_RFE$variables)
          
          cat('\n')
          cat('################ Recursive Feature Elimination - Accuracy values of  Different Variables ###########\n')
          print(featureSelect_RFE$results)
          
          # List the Chosen Features
          cat('\n')
          cat('################ Recursive Feature Elimination - Selected Features  ###########\n')
          cat(predictors(featureSelect_RFE))
          
          # Plot the Results
          par(mfrow=c(1,1))
          plot(featureSelect_RFE, type=c("g", "o"),main='Feature Selection - RFE (Variables vs Cross-Validation Accuracy)')
          
        }
        if(featureSelect_Method=="FSelector"){
          
          Y_train=data.frame(Y_train)
          colnames(Y_train)=TargetVarb_Name
          
          if(value=="InformationGain"){
            
            ###################### Feature Selection Based on Information Gain #########################
            cat('\n')
            cat('###################### Feature Selection Based on Information Gain #########################\n')
            
            #Calculating Information Gain for Each Attribute
            weights <- information.gain(as.formula(paste0(TargetVarb_Name,'~.')), cbind(X_train,Y_train))
            
            #Printing Attribute Importance Weights
            cat('\n')
            cat('#################### Attribute/Variable Importance Weights ################\n')
            weights1=data.frame(attributes=row.names(weights),attr_importance=weights$attr_importance)
            weights1=weights1[order(-weights1$attr_importance),]
            row.names(weights1)=c(1:nrow(weights1))
            
            #Print Attribute 
            cat('\n')
            print(weights1)
            
            ########## Selecting Top k ranked Attributes ###########
            subset <- cutoff.k(weights, k=k_attrb)
            f <- as.simple.formula(subset, "Species")
            
            #Printing Formula with Selected Attributes
            cat('\n')
            cat('################### Formula with Selected Attributes ###############\n')
            print(f)
            
          }else if(value=="GainRatio"){
            
            ###################### Feature Selection Based on Gain Ratio #########################
            cat('\n')
            cat('###################### Feature Selection Based on Gain Ratio #########################\n')
            
            #Calculating Gain Ratio for Each Attribute
            weights <- gain.ratio(as.formula(paste0(TargetVarb_Name,'~.')), cbind(X_train,Y_train))
            
            #Printing Attribute Importance Weights
            cat('\n')
            cat('#################### Attribute/Variable Importance Weights ################\n')
            print(weights)
            
            ########## Selecting Top k ranked Attributes ###########
            subset <- cutoff.k(weights, 2)
            f <- as.simple.formula(subset, "Species")
            
            #Printing Formula with Selected Attributes
            cat('\n')
            cat('################### Formula with Selected Attributes ###############\n')
            print(f)
            
          }else if(value=="SymmetricalUncertainity"){
            
            ###################### Feature Selection Based on Symmetrical Uncertainity #########################
            cat('\n')
            cat('###################### Feature Selection Based on Symmetrical Uncertainity #########################\n')
            
            #Calculating Symmetrical Uncertainity for Each Attribute
            weights <- symmetrical.uncertainty(as.formula(paste0(TargetVarb_Name,'~.')), cbind(X_train,Y_train))
            
            #Printing Attribute Importance Weights
            cat('\n')
            cat('#################### Attribute/Variable Importance Weights ################\n')
            print(weights)
            
            ########## Selecting Top k ranked Attributes ###########
            subset <- cutoff.biggest.diff(weights)
            f <- as.simple.formula(subset, "Species")
            
            #Printing Formula with Selected Attributes
            cat('\n')
            cat('################### Formula with Selected Attributes ###############\n')
            print(f)
            
          }
        }
}

#Sample Output
Feature_Selection(X_train,Y_train,TargetVarb_Name="Species",featureSelect_Method="FSelector")

