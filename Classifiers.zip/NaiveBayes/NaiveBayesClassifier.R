######################################### Supervised Learning/Classification - Naive Bayes ###########################################

#Function Name: Classifier_NaiveBayes
#Function Description: Builds Naive Bayes Model (klaR::NaiveBayes), Returns the Test Data with Predictions and 
#                     Save the Naive Bayes Model Results (i.e. Model Summary, Confusion Matrix, 
#                     ROC Curve(Binary Classification) etc.,) in specified working directory
#
#Function Arguments/Parameters: 
#      Mandatory Parameters: 
#           Data Specific Paramters: X_train, Y_train, X_test, Y_test
#           Target/Dependent Variable Specific Paramters: case_Class, TargetVarb_Name
#           
#      Optional Parameters: 
#           Working Directory Specific Parameters: work_directory
#           Tuning Specific Paramenters: 
#                 Cross Validation (Objective Functs: Minimizing Classification Error , Maximizing Sensitivity) Specific Parameters: k_fold, n_times
#                   
#Arguments/Parameters Description: 
#      Mandatory Parameters: 
#           Data Specific Parameters:
#                   X_train: Training Data - Independent Variables
#                   Y_train: Training Data - Dependent Variable
#                   X_test: Testing Data - Independent Variables
#                   Y_test: Testing Data - Dependent Variable
#           Target/Dependent Variable Specific Parameters:
#                   case_Class: Positive class of Target Variable
#                   TargetVarb_Name: Name of the Target/Dependent Variable
#           
#     Optional Parameters:
#           Working Directory Specific Parameters:
#                   work_directory: Working Directory to Save Naive Bayes Model Results (Model Object (.rds file), Confusion Matrix (.rds), 
#                                    ROC curve (Applicable for Binary Classification Problems)) Default Value: Present Working Directory
#           Tuning Specific Parameters:
#                   Cross Validation (Objective Functs: Minimizing Classification Error , Maximizing Sensitivity) Specific Parameters: 
#                           k_fold: Number of folds (The original sample is randomly partitioned into k equal sized subsamples/folds) Default Value: 10
#                           n_times: Number of times (i.e. How many times we have to repeact the Cross Validation)  Default Value: 10
#
# Assumptions and Dependencies:
#                 Assumptions:
#                       Data Prepared according to Naive Bayes Model Requirements (Data Preprocessing, Feature Selection, Checking Assumptions etc.,)
#                 Dependencies:
#                       Libraries: klaR, caret, ggplot2, ROCR
#
# Additional Information:
#                 Reference Links:
#                       klaR Package Documentation: https://cran.r-project.org/web/packages/klaR/klaR.pdf
#                       caret Package Documentation: https://cran.r-project.org/web/packages/caret/caret.pdf
#                       ggplot2 Package Documentation: https://cran.r-project.org/web/packages/ggplot2/ggplot2.pdf
#                       ROCR Package Documentation: https://cran.r-project.org/web/packages/ROCR/ROCR.pdf

#Loading Required Libraries
library(klaR)
library(caret)
library(ROCR)
library(ggplot2)

#Classifier_NaiveBayes Function Definition
Classifier_NaiveBayes<-function(X_train,Y_train,X_test,Y_test,case_Class,work_directory=getwd(),TargetVarb_Name){
  
  setwd(work_directory) #Set Working Directory
  
  ##################################### Model Building - Naive Bayes / Training Naive Bayes Model ####################### 
  #Fitting Naive Bayes model
  modelFit_naiveBayes=NaiveBayes(X_train,Y_train)
  
  cat('\n')     #Printing Naive Bayes Model Summary to R Console
  cat("########### Naive Bayes - Model Summary ###########\n")
  print(modelFit_naiveBayes)
  
  #Saving Naive Bayes Model Object to .rds file 
  saveRDS(modelFit_naiveBayes,'NaiveBayes_Model.rds')
  
  #################################### Predictions on Test Data ##################################
  #Predictions(i.e. Class) for Test data
  Y_test_predict_temp=predict(object=modelFit_naiveBayes,newdata=X_test)
  Y_test_predict=Y_test_predict_temp$class
  
  #Predictions(i.e. Probabilities) for Newdata
  probs_naiveBayes=Y_test_predict_temp$posterior
  probs_naiveBayes<-probs_naiveBayes[,1]
  
  ################################### Model Performace/Evaluation on Test Data ################################
  #Confusion Matrix on Test Data
  confMatrix_naiveBayes=confusionMatrix(Y_test_predict,Y_test,positive =case_Class )
  
  #Printing Confusion Matrix to R Console
  cat('\n')
  cat("########### Naive Bayes - Confusion Matrix on Test Data ###########\n")
  cat('\n')
  print(confMatrix_naiveBayes)
  
  #Saving Confusion Matrix to .rds file
  saveRDS(confMatrix_naiveBayes,'NaiveBayes_ConfusionMatrix.rds')
  
  #ROC Curve - Binary Classification
  if(length(unique(Y_test))==2){ 
    
    ####### ROC Curve and AUC Value #############
    pred_nb <- prediction(as.numeric(Y_test_predict),as.numeric(Y_test))
    perf_nb <- performance(pred_nb, measure = "tpr", x.measure = "fpr")
    auc <- performance(pred_nb, measure = "auc")
    auc <- auc@y.values[[1]]
    roc.data <- data.frame(fpr=unlist(perf_nb@x.values),tpr=unlist(perf_nb@y.values),model="Naive Bayes")
    
    #Plotting ROC Curve
    g=ggplot(roc.data, aes(x=fpr, ymin=0, ymax=tpr)) + geom_ribbon(alpha=0.2) + 
      geom_line( aes(y=tpr)) + ggtitle(paste0("ROC Curve w/ AUC=", auc))+theme_minimal()+
      theme(plot.title = element_text(color="#993333", size=16,hjust = 0.5, face="bold"),
            axis.title.x = element_text(color="#993333", size=14, face="bold.italic"),
            axis.title.y = element_text(color="#993333", size=14, face="bold.italic")
      )
    print(g)
    
    #Saving ROC Curve with AUC Value
    ggsave('NaiveBayes - ROC Curve with AUC Value.jpg',last_plot())
  }
  
  # Test Data frame with Prediction Classes and Probabilities 
  testDF_Predictions=cbind(X_test,Y_test,Y_test_predict,probs_naiveBayes)
  colnames(testDF_Predictions)[c((ncol(testDF_Predictions)-2),(ncol(testDF_Predictions)-1),
                                 ncol(testDF_Predictions))]=c(paste0("Actual_",TargetVarb_Name),paste0("Predicted_",TargetVarb_Name),
                                                              paste0("PredictedProbs_",TargetVarb_Name))
  
  #Return the Test Data frame with Prediction Classes and Probabilities
  return(testDF_Predictions)
}